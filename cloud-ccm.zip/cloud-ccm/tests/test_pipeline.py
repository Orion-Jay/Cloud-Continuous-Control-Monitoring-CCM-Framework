"""Scenario, drift, reporting and AI-summary tests."""

import json
from datetime import date

import pytest

from ccm import ai_summary, history
from ccm.cli import main
from ccm.collectors import MockCollector
from ccm.collectors.mock import as_of_datetime
from ccm.config import Policy, load_policy
from ccm.engine import evaluate
from ccm.exceptions import load_exceptions
from ccm.report import to_html, to_markdown

D = date(2026, 11, 17)


def run(scenario):
    snap = MockCollector(scenario).collect(as_of_datetime(D))
    return evaluate(snap, load_policy(None), load_exceptions(__import__("pathlib").Path("config/exceptions.toml")), D)


def by_id(res):
    return {c["id"]: c for c in res["controls"]}


def test_baseline_expected_results():
    c = by_id(run("baseline"))
    assert {k: v["status"] for k, v in c.items()} == {k: "FAIL" for k in c}
    assert c["CCM-01"]["counts"] == {"PASS": 4, "FAIL": 2, "EXCEPTION": 1}
    assert c["CCM-04"]["counts"] == {"PASS": 4, "FAIL": 4, "EXCEPTION": 1}

def test_remediated_improves_but_keeps_residual_issues():
    r = run("remediated"); c = by_id(r)
    assert c["CCM-03"]["status"] == c["CCM-05"]["status"] == "PASS"
    assert c["CCM-01"]["status"] == "EXCEPTION"
    assert c["CCM-02"]["status"] == c["CCM-04"]["status"] == "FAIL"
    assert r["summary"]["findings"]["FAIL"] == 2

def test_expired_and_invalid_exceptions_surface_in_register():
    states = {e["id"]: e for e in run("baseline")["exceptions"]}
    assert states["EXC-003"]["state"] == "expired"
    assert states["EXC-006"]["state"] == "invalid"
    assert states["EXC-005"]["unused"] and states["EXC-001"]["expiring_soon"]

def test_drift_between_runs():
    d = history.compute_drift(run("baseline"), run("remediated"))
    assert len(d["resolved"]) == 11 and d["new_failures"] == [] and d["unchanged_failures"] == 2

def test_drift_detects_regression_and_lapsed_exception():
    d = history.compute_drift(run("remediated"), run("baseline"))
    assert len(d["new_failures"]) == 11
    # dan.platform exception is still active in both, so nothing lapses here
    assert d["exceptions_lapsed"] == []

def test_lapsed_exception_detected_when_date_moves_on():
    snap = MockCollector("baseline").collect(as_of_datetime(D))
    recs = load_exceptions(__import__("pathlib").Path("config/exceptions.toml"))
    before = evaluate(snap, Policy(), recs, D)
    after = evaluate(snap, Policy(), recs, date(2026, 12, 15))  # EXC-001 expired 10 Dec
    lapsed = history.compute_drift(before, after)["exceptions_lapsed"]
    assert any(x["resource"] == "dan.platform" for x in lapsed)

def test_reports_render_and_escape_html():
    r = run("baseline"); r["executive_summary"] = ai_summary.generate(r, mode="off")
    r["controls"][0]["findings"][0]["resource"] = "<script>alert(1)</script>"
    html = to_html(r)
    assert "<script>alert(1)</script>" not in html and "&lt;script&gt;" in html
    assert "CCM-05" in to_markdown(r)

def test_cli_exit_codes_and_outputs(tmp_path, monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    base = ["run", "--config", "config", "--out", str(tmp_path), "--as-of", "2026-11-17", "--ai", "off"]
    assert main(base + ["--scenario", "baseline"]) == 1
    assert main(base + ["--scenario", "remediated", "--fail-on", "none"]) == 0
    assert main(base + ["--scenario", "nope"]) == 2
    assert (tmp_path / "report.html").exists() and len(list((tmp_path / "history").glob("*.json"))) == 2
    assert json.loads((tmp_path / "results.json").read_text())["drift"]["previous_as_of"] == "2026-11-17"


# ---- AI summary
class FakeClient:
    def __init__(self, text=None, exc=None):
        self.text, self.exc, self.calls = text, exc, []
        self.messages = self

    def create(self, **kw):
        self.calls.append(kw)
        if self.exc:
            raise self.exc
        return type("M", (), {"content": [type("B", (), {"type": "text", "text": self.text})()]})()

def test_payload_contains_no_resource_identifiers():
    blob = json.dumps(ai_summary.build_payload(run("baseline")))
    for secret in ("alice.admin", "acme-prod-customer-data", "vol-0a1b2c3d4e5f60002", "111122223333", "break-glass"):
        assert secret not in blob

def test_ai_path_sends_payload_and_checks_grounding():
    r = run("baseline")
    good = FakeClient("5 of 5 controls are failing and 13 checks fail.")
    out = ai_summary.generate(r, mode="on", client=good)
    assert out["source"] == "ai" and out["warnings"] == []
    assert good.calls[0]["system"] == ai_summary.SYSTEM_PROMPT

    bad = FakeClient("Failures rose to 47 this month.")
    assert "47" in ai_summary.generate(r, mode="on", client=bad)["warnings"][0]

def test_api_error_falls_back_to_template_in_auto_but_raises_in_on():
    r = run("baseline")
    out = ai_summary.generate(r, mode="auto", client=FakeClient(exc=RuntimeError("boom")))
    assert out["source"] == "template" and out["warnings"]
    with pytest.raises(RuntimeError):
        ai_summary.generate(r, mode="on", client=FakeClient(exc=RuntimeError("boom")))

def test_auto_without_key_uses_template(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    assert ai_summary.generate(run("baseline"))["source"] == "template"
    with pytest.raises(RuntimeError):
        ai_summary.generate(run("baseline"), mode="on")
