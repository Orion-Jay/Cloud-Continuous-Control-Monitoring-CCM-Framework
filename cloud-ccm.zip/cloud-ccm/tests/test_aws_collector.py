"""AWS collector tested against moto's simulated AWS. Skipped if moto isn't installed."""

import json
import os
from datetime import date

import pytest

moto = pytest.importorskip("moto")
boto3 = pytest.importorskip("boto3")

from ccm.collectors.aws import AwsCollector, doc_is_admin, policy_enforces_tls
from ccm.config import Policy
from ccm.engine import evaluate

REGION = "us-east-1"
ADMIN = "arn:aws:iam::aws:policy/AdministratorAccess"
TLS_POLICY = lambda b: json.dumps({"Version": "2012-10-17", "Statement": [{
    "Effect": "Deny", "Principal": "*", "Action": "s3:*", "Resource": [f"arn:aws:s3:::{b}", f"arn:aws:s3:::{b}/*"],
    "Condition": {"Bool": {"aws:SecureTransport": "false"}}}]})


@pytest.fixture(autouse=True)
def fake_creds(monkeypatch):
    for k, v in {"AWS_ACCESS_KEY_ID": "testing", "AWS_SECRET_ACCESS_KEY": "testing", "AWS_DEFAULT_REGION": REGION,
                 "MOTO_IAM_LOAD_MANAGED_POLICIES": "true"}.items():
        monkeypatch.setenv(k, v)


def build_account():
    iam = boto3.client("iam")
    # admin via attached policy, no MFA
    iam.create_user(UserName="admin.nomfa"); iam.create_login_profile(UserName="admin.nomfa", Password="Xx1!aaaaaaaa")
    iam.attach_user_policy(UserName="admin.nomfa", PolicyArn=ADMIN)
    # admin via group, with MFA
    iam.create_group(GroupName="Admins"); iam.attach_group_policy(GroupName="Admins", PolicyArn=ADMIN)
    iam.create_user(UserName="admin.mfa"); iam.create_login_profile(UserName="admin.mfa", Password="Xx1!aaaaaaaa")
    iam.add_user_to_group(GroupName="Admins", UserName="admin.mfa")
    dev = iam.create_virtual_mfa_device(VirtualMFADeviceName="admin.mfa")["VirtualMFADevice"]
    iam.enable_mfa_device(UserName="admin.mfa", SerialNumber=dev["SerialNumber"],
                          AuthenticationCode1="123456", AuthenticationCode2="654321")
    # admin via inline *:*
    iam.create_user(UserName="admin.inline")
    iam.put_user_policy(UserName="admin.inline", PolicyName="all", PolicyDocument=json.dumps(
        {"Version": "2012-10-17", "Statement": [{"Effect": "Allow", "Action": "*", "Resource": "*"}]}))
    # ordinary user
    iam.create_user(UserName="plain"); iam.create_login_profile(UserName="plain", Password="Xx1!aaaaaaaa")

    s3 = boto3.client("s3")
    for b in ("kms-tls", "sse-only", "trail-logs"):
        s3.create_bucket(Bucket=b)
    s3.put_bucket_encryption(Bucket="kms-tls", ServerSideEncryptionConfiguration={"Rules": [
        {"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "aws:kms"}}]})
    s3.put_bucket_policy(Bucket="kms-tls", Policy=TLS_POLICY("kms-tls"))

    boto3.client("cloudtrail").create_trail(Name="main", S3BucketName="trail-logs", IsMultiRegionTrail=True,
                                            EnableLogFileValidation=True)
    ec2 = boto3.client("ec2")
    ec2.create_volume(AvailabilityZone=f"{REGION}a", Size=1, Encrypted=True)
    ec2.create_volume(AvailabilityZone=f"{REGION}a", Size=1, Encrypted=False)


@moto.mock_aws
def test_collects_and_evaluates_simulated_account():
    build_account()
    snap = AwsCollector(Policy()).collect()
    assert snap.errors == {} or set(snap.errors) <= {"rds"}  # moto's RDS needs no setup; tolerate engine gaps

    users = {u.name: u for u in snap.users}
    assert users["admin.nomfa"].privileged and "AdministratorAccess" in users["admin.nomfa"].privilege_reason
    assert users["admin.mfa"].privileged and "via group Admins" in users["admin.mfa"].privilege_reason
    assert users["admin.mfa"].mfa_enabled and not users["admin.nomfa"].mfa_enabled
    assert users["admin.inline"].privileged and "inline" in users["admin.inline"].privilege_reason
    assert not users["plain"].privileged

    s3 = {s.id: s for s in snap.storage if s.kind == "s3"}
    assert s3["kms-tls"].algorithm == "aws:kms" and s3["kms-tls"].enforces_tls
    assert not s3["sse-only"].enforces_tls
    assert sorted(v.encrypted for v in snap.storage if v.kind == "ebs") == [False, True]
    assert snap.trails[0].name == "main" and snap.trails[0].multi_region and snap.trails[0].log_file_validation

    res = evaluate(snap, Policy(), [], date.today())
    c = {x["id"]: x for x in res["controls"]}
    mfa_fail = {f["resource"] for f in c["CCM-01"]["findings"] if f["status"] == "FAIL"}
    assert "admin.nomfa" in mfa_fail and "admin.mfa" not in mfa_fail
    assert c["CCM-05"]["counts"]["FAIL"] >= 1


@moto.mock_aws
def test_permission_failure_yields_error_not_pass():
    class Denied:
        region_name = REGION
        def client(self, name, **kw):
            raise PermissionError(f"AccessDenied for {name}")
    snap = AwsCollector(Policy(), session=Denied()).collect()
    assert {"iam", "cloudtrail", "s3"} <= set(snap.errors)
    res = evaluate(snap, Policy(), [], date.today())
    statuses = {c["id"]: c["status"] for c in res["controls"]}
    assert statuses["CCM-01"] == statuses["CCM-02"] == statuses["CCM-04"] == statuses["CCM-05"] == "ERROR"


def test_policy_parsers():
    assert doc_is_admin({"Statement": {"Effect": "Allow", "Action": ["*"], "Resource": "*"}})
    assert not doc_is_admin({"Statement": [{"Effect": "Allow", "Action": "s3:*", "Resource": "*"}]})
    assert not doc_is_admin({"Statement": [{"Effect": "Deny", "Action": "*", "Resource": "*"}]})
    assert policy_enforces_tls(TLS_POLICY("b"))
    assert not policy_enforces_tls(json.dumps({"Statement": [{"Effect": "Allow", "Action": "s3:*", "Resource": "*"}]}))


def test_root_row_from_credential_report_is_parsed(monkeypatch):
    """Real AWS always includes a <root_account> row; moto does not, so feed one in."""
    header = ("user,arn,user_creation_time,password_enabled,password_last_used,password_last_changed,"
              "password_next_rotation,mfa_active,access_key_1_active,access_key_1_last_rotated,"
              "access_key_1_last_used_date,access_key_1_last_used_region,access_key_1_last_used_service,"
              "access_key_2_active,access_key_2_last_rotated,access_key_2_last_used_date,"
              "access_key_2_last_used_region,access_key_2_last_used_service")
    root = ("<root_account>,arn:aws:iam::111122223333:root,2019-01-01T00:00:00+00:00,not_supported,"
            "2026-09-01T10:00:00+00:00,not_supported,not_supported,false,true,2019-01-02T00:00:00+00:00,"
            "N/A,N/A,N/A,false,N/A,N/A,N/A,N/A")
    import csv, io
    rows = list(csv.DictReader(io.StringIO(header + "\n" + root)))

    class Iam:
        pass
    c = AwsCollector(Policy(), session=type("S", (), {"region_name": REGION, "client": lambda s, n, **k: Iam()})())
    monkeypatch.setattr(c, "_credential_report", lambda: rows)
    (u,) = c._users()
    assert u.is_root and u.privileged and u.console_access
    assert not u.mfa_enabled and u.access_keys_active == 1
    assert u.last_activity.year == 2026 and u.created.year == 2019
