"""Unit tests for the deterministic checks and the exception engine."""

from datetime import date, datetime, timedelta, timezone

import pytest

from ccm.config import ConfigError, Policy, load_policy
from ccm.controls import (check_audit_logging, check_encryption_at_rest, check_encryption_in_transit,
                          check_inactive_accounts, check_privileged_mfa)
from ccm.engine import evaluate
from ccm.exceptions import ExceptionRecord, apply_exceptions
from ccm.models import Finding, Snapshot, Status, StorageResource, Trail, User

NOW = datetime(2026, 11, 17, 12, 0, tzinfo=timezone.utc)
P = Policy()


def snap(**kw):
    return Snapshot(source="test", account_id="1", account_alias="t", collected_at=NOW, **kw)


def user(name="u", **kw):
    base = dict(name=name, arn=f"arn:{name}", privileged=False, privilege_reason="", console_access=True,
                mfa_enabled=True, created=NOW - timedelta(days=500), last_activity=NOW - timedelta(days=1))
    base.update(kw)
    return User(**base)


def status_of(findings, resource):
    return next(f.status for f in findings if f.resource == resource)


# ---- CCM-01
def test_privileged_without_mfa_fails():
    r = check_privileged_mfa(snap(users=[user("a", privileged=True, mfa_enabled=False)]), P)
    assert status_of(r, "a") is Status.FAIL

def test_non_privileged_users_are_out_of_scope():
    assert check_privileged_mfa(snap(users=[user("a", mfa_enabled=False)]), P) == []

def test_root_with_access_key_fails_even_with_mfa():
    root = user("root", privileged=True, is_root=True, access_keys_active=1)
    f = check_privileged_mfa(snap(users=[root]), P)[0]
    assert f.status is Status.FAIL and f.reasons == ["root_access_key"]

def test_programmatic_only_privileged_passes_with_note():
    f = check_privileged_mfa(snap(users=[user("ci", privileged=True, console_access=False, mfa_enabled=False)]), P)[0]
    assert f.status is Status.PASS and "Programmatic" in f.detail


# ---- CCM-02
@pytest.mark.parametrize("idle,expected", [(90, Status.PASS), (91, Status.FAIL)])
def test_inactivity_boundary(idle, expected):
    u = user("a", last_activity=NOW - timedelta(days=idle))
    assert status_of(check_inactive_accounts(snap(users=[u]), P), "a") is expected

def test_never_used_old_account_fails_but_new_one_passes():
    old = user("old", last_activity=None, created=NOW - timedelta(days=120))
    new = user("new", last_activity=None, created=NOW - timedelta(days=5))
    r = check_inactive_accounts(snap(users=[old, new]), P)
    assert status_of(r, "old") is Status.FAIL and status_of(r, "new") is Status.PASS

def test_account_without_credentials_passes_and_root_is_skipped():
    dead = user("dead", console_access=False, access_keys_active=0, last_activity=NOW - timedelta(days=900))
    root = user("root", is_root=True, last_activity=NOW - timedelta(days=900))
    r = check_inactive_accounts(snap(users=[dead, root]), P)
    assert [f.resource for f in r] == ["dead"] and r[0].status is Status.PASS

def test_threshold_comes_from_policy():
    u = user("a", last_activity=NOW - timedelta(days=40))
    assert status_of(check_inactive_accounts(snap(users=[u]), Policy(inactive_days=30)), "a") is Status.FAIL


# ---- CCM-03
GOOD = Trail("t", "us-east-1", True, True, True, True)

def test_no_trails_fails_coverage():
    r = check_audit_logging(snap(), P)
    assert len(r) == 1 and r[0].status is Status.FAIL and r[0].reasons == ["no_trail"]

def test_good_trail_passes():
    assert all(f.status is Status.PASS for f in check_audit_logging(snap(trails=[GOOD]), P))

def test_trail_reasons_are_collected():
    bad = Trail("t", "us-east-1", True, False, False, False)
    f = [x for x in check_audit_logging(snap(trails=[bad]), P) if x.resource == "t"][0]
    assert f.reasons == ["trail_stopped", "log_validation_off", "log_kms_off"]

def test_kms_requirement_can_be_relaxed():
    t = Trail("t", "us-east-1", True, True, True, False)
    assert status_of(check_audit_logging(snap(trails=[t]), Policy(require_log_kms=False)), "t") is Status.PASS


# ---- CCM-04 / 05
def s3(name, enc=True, algo="aws:kms", tls=True):
    return StorageResource("s3", name, "g", enc, algo, tls)

def test_encryption_at_rest_matrix():
    st = [s3("kms"), s3("sse", algo="AES256"), s3("none", enc=False, algo=""),
          StorageResource("ebs", "v1", "r", True), StorageResource("ebs", "v2", "r", False),
          StorageResource("rds", "d1", "r", False)]
    r = check_encryption_at_rest(snap(storage=st), P)
    got = {f.resource: f.status for f in r}
    assert got == {"kms": Status.PASS, "sse": Status.FAIL, "none": Status.FAIL,
                   "v1": Status.PASS, "v2": Status.FAIL, "d1": Status.FAIL}

def test_sse_s3_allowed_when_policy_relaxed():
    r = check_encryption_at_rest(snap(storage=[s3("sse", algo="AES256")]), Policy(s3_require_kms=False))
    assert r[0].status is Status.PASS

def test_tls_check_only_covers_s3():
    st = [s3("a", tls=True), s3("b", tls=False), StorageResource("ebs", "v", "r", True)]
    got = {f.resource: f.status for f in check_encryption_in_transit(snap(storage=st), P)}
    assert got == {"a": Status.PASS, "b": Status.FAIL}


# ---- exceptions
def fail(cid="CCM-02", res="svc"):
    return Finding(cid, res, "IAM user", Status.FAIL, "bad", ["inactive"])

def rec(**kw):
    base = dict(id="EXC-1", control_id="CCM-02", resource="svc", reason="r", approved_by="CISO",
                approved_on=date(2026, 10, 1), expires_on=date(2026, 12, 1))
    base.update(kw)
    return ExceptionRecord(**base)

TODAY = date(2026, 11, 17)

def test_active_exception_downgrades_fail():
    f = fail(); rows = apply_exceptions([f], [rec()], TODAY, P)
    assert f.status is Status.EXCEPTION and f.exception_id == "EXC-1" and not rows[0]["unused"]

def test_expired_exception_is_not_honoured():
    f = fail(); rows = apply_exceptions([f], [rec(expires_on=date(2026, 11, 1))], TODAY, P)
    assert f.status is Status.FAIL and "not honoured" in f.note and rows[0]["state"] == "expired"

def test_over_long_exception_is_invalid():
    f = fail(); rows = apply_exceptions([f], [rec(approved_on=date(2026, 1, 1), expires_on=date(2027, 1, 1))], TODAY, P)
    assert f.status is Status.FAIL and rows[0]["state"] == "invalid"

def test_wrong_control_does_not_match():
    f = fail("CCM-01"); apply_exceptions([f], [rec()], TODAY, P)
    assert f.status is Status.FAIL

def test_glob_patterns_match():
    fs = [fail(res="legacy-1"), fail(res="legacy-2"), fail(res="other")]
    apply_exceptions(fs, [rec(resource="legacy-*")], TODAY, P)
    assert [f.status for f in fs] == [Status.EXCEPTION, Status.EXCEPTION, Status.FAIL]

def test_exception_for_passing_or_missing_resource_is_flagged_unused():
    ok = Finding("CCM-02", "svc", "IAM user", Status.PASS, "fine")
    assert apply_exceptions([ok], [rec()], TODAY, P)[0]["unused"] is True

def test_expiring_soon_flag():
    row = apply_exceptions([fail()], [rec(expires_on=date(2026, 12, 1))], TODAY, P)[0]
    assert row["expiring_soon"] is True and row["days_remaining"] == 14


# ---- engine invariants
def test_incomplete_evidence_is_never_pass():
    s = snap(users=[user("a")]); s.errors = {"iam": ["AccessDenied"]}
    res = evaluate(s, P, [], TODAY)
    c = {c["id"]: c for c in res["controls"]}
    assert c["CCM-01"]["status"] == "ERROR" and c["CCM-02"]["status"] == "ERROR"
    assert c["CCM-03"]["status"] == "FAIL"  # unrelated domain unaffected: no trails

def test_fail_outranks_error():
    s = snap(users=[user("a", privileged=True, mfa_enabled=False)]); s.errors = {"iam": ["x"]}
    assert evaluate(s, P, [], TODAY)["controls"][0]["status"] == "FAIL"

def test_empty_scope_is_na():
    res = evaluate(snap(), P, [], TODAY)
    assert {c["id"]: c["status"] for c in res["controls"]}["CCM-05"] == "N/A"


# ---- config
def test_unknown_policy_key_is_rejected(tmp_path):
    f = tmp_path / "s.toml"; f.write_text("[policy]\ninactve_days = 30\n")
    with pytest.raises(ConfigError):
        load_policy(f)

def test_policy_overrides_load(tmp_path):
    f = tmp_path / "s.toml"; f.write_text("[policy]\ninactive_days = 45\n[aws]\nregions=['eu-west-1']\n")
    p = load_policy(f)
    assert p.inactive_days == 45 and p.regions == ("eu-west-1",)
