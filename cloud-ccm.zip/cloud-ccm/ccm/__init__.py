"""cloud-ccm: a small Continuous Control Monitoring (CCM) engine."""

__version__ = "1.0.0"
