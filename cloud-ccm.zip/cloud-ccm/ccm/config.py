"""Policy thresholds, loaded from config/settings.toml.

Unknown keys are rejected on purpose: a typo in a compliance threshold
(``inactve_days``) should stop the run, not silently fall back to a default.
"""

from __future__ import annotations

import tomllib
from dataclasses import asdict, dataclass, fields
from pathlib import Path


class ConfigError(Exception):
    pass


@dataclass(frozen=True)
class Policy:
    inactive_days: int = 90  # PCI DSS v4.0.1 8.2.6
    max_exception_days: int = 180  # exceptions longer than this are not honoured
    expiring_soon_days: int = 30
    s3_require_kms: bool = True  # SSE-S3 alone is not enough for regulated data
    require_log_file_validation: bool = True
    require_log_kms: bool = True
    privileged_policies: tuple[str, ...] = (
        "arn:aws:iam::aws:policy/AdministratorAccess",
        "arn:aws:iam::aws:policy/IAMFullAccess",
    )
    regions: tuple[str, ...] = ()  # AWS only. () = session region; ("all",) = every region

    def to_dict(self) -> dict:
        return {k: list(v) if isinstance(v, tuple) else v for k, v in asdict(self).items()}


def load_policy(path: Path | None) -> Policy:
    if path is None or not path.exists():
        return Policy()
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"{path}: invalid TOML ({exc})") from exc

    values = dict(data.get("policy", {}))
    if "regions" in data.get("aws", {}):
        values["regions"] = data["aws"]["regions"]

    known = {f.name: f for f in fields(Policy)}
    unknown = sorted(set(values) - set(known))
    if unknown:
        raise ConfigError(f"{path}: unknown setting(s): {', '.join(unknown)}")

    for key, value in values.items():
        if isinstance(known[key].default, tuple):
            values[key] = tuple(value)
    return Policy(**values)
