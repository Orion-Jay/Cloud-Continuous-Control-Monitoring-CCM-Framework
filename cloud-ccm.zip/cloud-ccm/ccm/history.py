"""Run history and drift detection.

"Continuous" monitoring is only useful if you can say what changed since the
last run. Each run is saved as JSON; the next run diffs against the latest.
"""

from __future__ import annotations

import json
from pathlib import Path


def latest(history_dir: Path) -> dict | None:
    files = sorted(history_dir.glob("*.json")) if history_dir.exists() else []
    if not files:
        return None
    return json.loads(files[-1].read_text(encoding="utf-8"))


def save(history_dir: Path, results: dict) -> Path:
    history_dir.mkdir(parents=True, exist_ok=True)
    path = history_dir / f"{results['run']['id']}.json"
    path.write_text(json.dumps(results, indent=2), encoding="utf-8")
    return path


def _index(results: dict) -> dict[tuple[str, str], dict]:
    return {(f["control_id"], f["resource"]): f for c in results["controls"] for f in c["findings"]}


def compute_drift(previous: dict, current: dict) -> dict:
    prev, curr = _index(previous), _index(current)
    new_failures, lapsed, resolved, newly_excepted, unchanged = [], [], [], [], 0

    def row(key, f, extra=""):
        return {"control_id": key[0], "resource": key[1], "detail": (f["detail"] + extra).strip()}

    for key, f in curr.items():
        before = prev.get(key, {}).get("status")
        if f["status"] == "FAIL":
            if before == "FAIL":
                unchanged += 1
            elif before == "EXCEPTION":
                lapsed.append(row(key, f, f" ({f['note']})" if f["note"] else ""))
            else:
                new_failures.append(row(key, f))
        elif f["status"] == "EXCEPTION" and before == "FAIL":
            newly_excepted.append(row(key, f))
        elif f["status"] == "PASS" and before in ("FAIL", "EXCEPTION"):
            resolved.append(row(key, f, " (now compliant)"))

    for key, f in prev.items():
        if key not in curr and f["status"] in ("FAIL", "EXCEPTION"):
            resolved.append(row(key, f, " (resource no longer present)"))

    ps, cs = previous["summary"], current["summary"]
    return {
        "previous_run_id": previous["run"]["id"],
        "previous_as_of": previous["run"]["as_of"],
        "previous_source": previous["run"]["source"],
        "new_failures": new_failures,
        "exceptions_lapsed": lapsed,
        "resolved": resolved,
        "newly_excepted": newly_excepted,
        "unchanged_failures": unchanged,
        "fail_delta": cs["findings"]["FAIL"] - ps["findings"]["FAIL"],
        "rate_before": ps["compliance_rate_strict"],
        "rate_after": cs["compliance_rate_strict"],
    }
