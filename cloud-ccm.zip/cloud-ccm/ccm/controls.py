"""The control catalogue and the deterministic checks behind it.

Every check is a pure function: ``(Snapshot, Policy) -> list[Finding]``.
No network calls, no randomness, no AI. Given the same evidence, the same
result comes out, which is what makes the output defensible to an auditor.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from .config import Policy
from .models import Finding, Severity, Snapshot, Status

# Stable reason codes -> human label. Codes are what drift detection and the
# AI summary key on, so renaming a label never changes behaviour.
REASONS = {
    "mfa_missing": "Privileged console user has no MFA device",
    "root_mfa_missing": "Root account has no MFA device",
    "root_access_key": "Root account has an active access key",
    "inactive": "Account inactive beyond the policy threshold",
    "never_used": "Account has never been used",
    "no_trail": "No active multi-region CloudTrail trail",
    "trail_stopped": "Trail exists but logging is switched off",
    "log_validation_off": "Log file integrity validation is disabled",
    "log_kms_off": "Trail logs are not encrypted with a KMS key",
    "unencrypted": "Storage is not encrypted at rest",
    "s3_not_kms": "S3 bucket uses SSE-S3 where a KMS key is required",
    "no_tls": "Bucket policy does not deny non-TLS requests",
}


@dataclass(frozen=True)
class Control:
    id: str
    title: str
    description: str
    severity: Severity
    requires: tuple[str, ...]  # evidence domains this control depends on
    mappings: dict[str, list[str]]
    remediation: str
    check: Callable[[Snapshot, Policy], list[Finding]]


def _finding(cid, resource, rtype, ok, ok_detail, reasons=(), extra=""):
    detail = ok_detail if ok else "; ".join(REASONS[r] for r in reasons)
    if extra:
        detail = f"{detail} ({extra})"
    return Finding(cid, resource, rtype, Status.PASS if ok else Status.FAIL, detail, list(reasons))


# ------------------------------------------------------------------ CCM-01 ----


def check_privileged_mfa(snap: Snapshot, policy: Policy) -> list[Finding]:
    out = []
    for u in snap.users:
        if not u.privileged:
            continue
        rtype = "Root account" if u.is_root else "IAM user (privileged)"
        reasons = []
        if u.console_access and not u.mfa_enabled:
            reasons.append("root_mfa_missing" if u.is_root else "mfa_missing")
        if u.is_root and u.access_keys_active > 0:
            reasons.append("root_access_key")

        if reasons:
            out.append(_finding("CCM-01", u.name, rtype, False, "", reasons))
        elif not u.console_access:
            out.append(
                _finding(
                    "CCM-01", u.name, rtype, True,
                    "Programmatic-only identity; console MFA not applicable "
                    "(review key hygiene separately)",
                )
            )
        else:
            out.append(_finding("CCM-01", u.name, rtype, True, "MFA enabled"))
    return out


# ------------------------------------------------------------------ CCM-02 ----


def check_inactive_accounts(snap: Snapshot, policy: Policy) -> list[Finding]:
    out = []
    for u in snap.users:
        if u.is_root:
            continue  # an unused root account is the goal, not a finding
        if not u.has_active_credentials:
            out.append(
                _finding("CCM-02", u.name, "IAM user", True,
                         "No active credentials (effectively disabled)")
            )
            continue

        never = u.last_activity is None
        idle = (snap.collected_at - (u.last_activity or u.created)).days
        if idle > policy.inactive_days:
            code = "never_used" if never else "inactive"
            extra = (
                f"created {idle} days ago, never used"
                if never
                else f"idle {idle} days, threshold {policy.inactive_days}"
            )
            out.append(_finding("CCM-02", u.name, "IAM user", False, "", [code], extra))
        else:
            out.append(
                _finding("CCM-02", u.name, "IAM user", True,
                         f"Active within threshold (last activity {idle} days ago)"
                         if not never else f"New account, not yet used ({idle} days old)")
            )
    return out


# ------------------------------------------------------------------ CCM-03 ----


def check_audit_logging(snap: Snapshot, policy: Policy) -> list[Finding]:
    out = []
    covered = any(t.logging and t.multi_region for t in snap.trails)
    scope = f"account {snap.account_id}"
    out.append(
        _finding("CCM-03", scope, "Account logging coverage", covered,
                 "At least one active multi-region trail", ["no_trail"])
    )
    for t in snap.trails:
        reasons = []
        if not t.logging:
            reasons.append("trail_stopped")
        if policy.require_log_file_validation and not t.log_file_validation:
            reasons.append("log_validation_off")
        if policy.require_log_kms and not t.kms_encrypted:
            reasons.append("log_kms_off")
        out.append(
            _finding("CCM-03", t.name, "CloudTrail trail", not reasons,
                     "Logging on, integrity validation on, KMS-encrypted", reasons)
        )
    return out


# ------------------------------------------------------------------ CCM-04 ----

_KMS = {"aws:kms", "aws:kms:dsse"}
_RTYPE = {"s3": "S3 bucket", "ebs": "EBS volume", "rds": "RDS instance"}


def check_encryption_at_rest(snap: Snapshot, policy: Policy) -> list[Finding]:
    out = []
    for r in snap.storage:
        rtype = _RTYPE[r.kind]
        if not r.encrypted:
            out.append(_finding("CCM-04", r.id, rtype, False, "", ["unencrypted"]))
        elif r.kind == "s3" and policy.s3_require_kms and r.algorithm not in _KMS:
            out.append(_finding("CCM-04", r.id, rtype, False, "", ["s3_not_kms"]))
        else:
            algo = f" ({r.algorithm})" if r.algorithm else ""
            out.append(_finding("CCM-04", r.id, rtype, True, f"Encrypted at rest{algo}"))
    return out


# ------------------------------------------------------------------ CCM-05 ----


def check_encryption_in_transit(snap: Snapshot, policy: Policy) -> list[Finding]:
    return [
        _finding("CCM-05", r.id, "S3 bucket", bool(r.enforces_tls),
                 "Bucket policy denies non-TLS requests", ["no_tls"])
        for r in snap.storage
        if r.kind == "s3"
    ]


# ---------------------------------------------------------------- catalogue ----

CONTROLS: list[Control] = [
    Control(
        id="CCM-01",
        title="MFA enforced for privileged accounts",
        description="Every privileged identity that can sign in to the console must "
        "use multi-factor authentication. The root account must also have no "
        "active access keys.",
        severity=Severity.CRITICAL,
        requires=("iam",),
        mappings={
            "ISO 27001:2022": ["A.8.5"],
            "PCI DSS v4.0.1": ["8.4.1"],
            "NIST CSF 2.0": ["PR.AA-03"],
            "SOC 2": ["CC6.1"],
        },
        remediation="Register a hardware or virtual MFA device. For root, remove "
        "access keys and use root only for break-glass tasks.",
        check=check_privileged_mfa,
    ),
    Control(
        id="CCM-02",
        title="Inactive accounts disabled or removed",
        description="Accounts with no activity beyond the policy threshold (default "
        "90 days) must be disabled or removed. Never-used accounts count as inactive.",
        severity=Severity.HIGH,
        requires=("iam",),
        mappings={
            "ISO 27001:2022": ["A.5.18"],
            "PCI DSS v4.0.1": ["8.2.6"],
            "NIST CSF 2.0": ["PR.AA-05"],
            "SOC 2": ["CC6.2"],
        },
        remediation="Deactivate console access and access keys, confirm with the "
        "account owner, then delete. Use an exception for approved break-glass accounts.",
        check=check_inactive_accounts,
    ),
    Control(
        id="CCM-03",
        title="Audit logging enabled and protected",
        description="At least one multi-region trail must be actively logging, and "
        "each trail must have log file integrity validation and KMS encryption.",
        severity=Severity.CRITICAL,
        requires=("cloudtrail",),
        mappings={
            "ISO 27001:2022": ["A.8.15"],
            "PCI DSS v4.0.1": ["10.2.1", "10.3.4"],
            "NIST CSF 2.0": ["DE.CM-03"],
            "SOC 2": ["CC7.2"],
        },
        remediation="Start logging, enable log file validation, and attach a "
        "customer-managed KMS key to the trail.",
        check=check_audit_logging,
    ),
    Control(
        id="CCM-04",
        title="Encryption at rest enabled",
        description="S3 buckets (with a KMS key where required by policy), EBS "
        "volumes and RDS instances must be encrypted at rest.",
        severity=Severity.HIGH,
        requires=("s3", "ebs", "rds"),
        mappings={
            "ISO 27001:2022": ["A.8.24"],
            "PCI DSS v4.0.1": ["3.5.1"],
            "NIST CSF 2.0": ["PR.DS-01"],
            "SOC 2": ["CC6.1"],
        },
        remediation="Copy unencrypted volumes/instances via an encrypted snapshot; "
        "set a default KMS encryption rule on S3 buckets.",
        check=check_encryption_at_rest,
    ),
    Control(
        id="CCM-05",
        title="Encryption in transit enforced on object storage",
        description="S3 bucket policies must deny any request that is not made over TLS.",
        severity=Severity.MEDIUM,
        requires=("s3",),
        mappings={
            "ISO 27001:2022": ["A.8.24"],
            "PCI DSS v4.0.1": ["4.2.1"],
            "NIST CSF 2.0": ["PR.DS-02"],
            "SOC 2": ["CC6.7"],
        },
        remediation="Add a Deny statement with condition aws:SecureTransport = false.",
        check=check_encryption_in_transit,
    ),
]
