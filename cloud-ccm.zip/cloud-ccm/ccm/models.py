"""Core data structures shared by collectors, checks and reports.

The collectors turn provider-specific API output into a normalised
``Snapshot``. The checks only ever see a ``Snapshot``, so adding another
cloud later means writing one new collector and nothing else.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class Status(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    EXCEPTION = "EXCEPTION"  # failed, but covered by an approved, in-date exception
    ERROR = "ERROR"  # evidence could not be collected; never reported as PASS
    NA = "N/A"  # control has no in-scope resources


class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    @property
    def rank(self) -> int:
        return ["low", "medium", "high", "critical"].index(self.value)


# ---------------------------------------------------------------- evidence ----


@dataclass
class User:
    name: str
    arn: str
    privileged: bool
    privilege_reason: str
    console_access: bool
    mfa_enabled: bool
    created: datetime
    last_activity: datetime | None  # latest of console sign-in / access-key use
    access_keys_active: int = 0
    is_root: bool = False

    @property
    def has_active_credentials(self) -> bool:
        return self.console_access or self.access_keys_active > 0


@dataclass
class Trail:
    name: str
    home_region: str
    multi_region: bool
    logging: bool
    log_file_validation: bool
    kms_encrypted: bool


@dataclass
class StorageResource:
    kind: str  # "s3" | "ebs" | "rds"
    id: str
    region: str
    encrypted: bool
    algorithm: str = ""  # s3 only: "AES256" | "aws:kms" | "aws:kms:dsse"
    enforces_tls: bool | None = None  # s3 only


@dataclass
class Snapshot:
    source: str
    account_id: str
    account_alias: str
    collected_at: datetime
    users: list[User] = field(default_factory=list)
    trails: list[Trail] = field(default_factory=list)
    storage: list[StorageResource] = field(default_factory=list)
    # evidence domain -> messages. A domain listed here could not be fully
    # collected, so any control that depends on it cannot be reported as PASS.
    errors: dict[str, list[str]] = field(default_factory=dict)


# ----------------------------------------------------------------- results ----


@dataclass
class Finding:
    control_id: str
    resource: str
    resource_type: str
    status: Status
    detail: str
    reasons: list[str] = field(default_factory=list)  # stable machine codes
    exception_id: str | None = None
    note: str = ""

    def to_dict(self) -> dict:
        return {
            "control_id": self.control_id,
            "resource": self.resource,
            "resource_type": self.resource_type,
            "status": self.status.value,
            "detail": self.detail,
            "reasons": self.reasons,
            "exception_id": self.exception_id,
            "note": self.note,
        }
