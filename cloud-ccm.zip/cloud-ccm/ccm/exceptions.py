"""Exception register: approved, time-boxed deviations from a control.

An exception only downgrades a FAIL to EXCEPTION when it is in date, within
the maximum duration the policy allows, and carries an approver. Expired or
over-long exceptions are *not* honoured: the finding stays FAIL and says why.
Exceptions that match nothing are reported as unused so the register stays clean.
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from datetime import date
from fnmatch import fnmatchcase
from pathlib import Path

from .config import ConfigError, Policy
from .models import Finding, Status

_REQUIRED = ("id", "control_id", "resource", "reason", "approved_by", "approved_on", "expires_on")


@dataclass
class ExceptionRecord:
    id: str
    control_id: str
    resource: str  # exact name or glob pattern, e.g. "legacy-archive-*"
    reason: str
    approved_by: str
    approved_on: date
    expires_on: date
    compensating_control: str = ""

    def assess(self, as_of: date, policy: Policy) -> tuple[str, str]:
        """Return (state, explanation). state is active | expired | invalid."""
        duration = (self.expires_on - self.approved_on).days
        if duration <= 0:
            return "invalid", "Expiry date is not after approval date"
        if duration > policy.max_exception_days:
            return "invalid", (
                f"Duration {duration} days exceeds the {policy.max_exception_days}-day policy maximum"
            )
        if self.expires_on < as_of:
            return "expired", f"Expired on {self.expires_on.isoformat()}"
        return "active", f"Valid until {self.expires_on.isoformat()}"


def load_exceptions(path: Path | None) -> list[ExceptionRecord]:
    if path is None or not path.exists():
        return []
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"{path}: invalid TOML ({exc})") from exc

    records, seen = [], set()
    for i, raw in enumerate(data.get("exception", []), start=1):
        missing = [k for k in _REQUIRED if k not in raw]
        if missing:
            raise ConfigError(f"{path}: exception #{i} is missing {', '.join(missing)}")
        for key in ("approved_on", "expires_on"):
            if not isinstance(raw[key], date):
                raise ConfigError(f"{path}: {raw['id']}.{key} must be a TOML date (YYYY-MM-DD)")
        if raw["id"] in seen:
            raise ConfigError(f"{path}: duplicate exception id {raw['id']}")
        seen.add(raw["id"])
        records.append(ExceptionRecord(**{k: raw[k] for k in raw if k in ExceptionRecord.__dataclass_fields__}))
    return records


def apply_exceptions(
    findings: list[Finding], records: list[ExceptionRecord], as_of: date, policy: Policy
) -> list[dict]:
    """Mutate FAIL findings covered by a valid exception; return register rows."""
    rows = []
    for rec in records:
        state, explanation = rec.assess(as_of, policy)
        days_left = (rec.expires_on - as_of).days
        matched = []

        for f in findings:
            if f.control_id != rec.control_id or not fnmatchcase(f.resource, rec.resource):
                continue
            if f.status is Status.FAIL:
                matched.append(f.resource)
                if state == "active":
                    f.status = Status.EXCEPTION
                    f.exception_id = rec.id
                    f.note = f"Covered by {rec.id}: {rec.reason}"
                else:
                    f.note = f"{rec.id} not honoured. {explanation}"

        rows.append(
            {
                "id": rec.id,
                "control_id": rec.control_id,
                "resource": rec.resource,
                "reason": rec.reason,
                "approved_by": rec.approved_by,
                "approved_on": rec.approved_on.isoformat(),
                "expires_on": rec.expires_on.isoformat(),
                "compensating_control": rec.compensating_control,
                "state": state,
                "state_detail": explanation,
                "days_remaining": days_left,
                "expiring_soon": state == "active" and days_left <= policy.expiring_soon_days,
                "unused": not matched,
                "matched_resources": matched,
            }
        )
    return rows
