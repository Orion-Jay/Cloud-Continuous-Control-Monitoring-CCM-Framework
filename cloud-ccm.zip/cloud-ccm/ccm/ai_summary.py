"""Executive summary: Claude narrates, code decides.

Governance rules baked in:
  * Claude never decides pass/fail. The deterministic engine does; Claude only
    summarises its aggregated output.
  * Data minimisation: the prompt contains counts and issue categories only.
    No usernames, bucket names, volume IDs, ARNs or account IDs leave the machine.
  * Grounding check: every number in the narrative must appear in the data that
    was sent. Unmatched figures are flagged in the report instead of trusted.
  * Graceful degradation: no API key (or an API error) falls back to a
    deterministic template, and the report says which one you are reading.
"""

from __future__ import annotations

import json
import os
import re

DEFAULT_MODEL = "claude-sonnet-5-5"

SYSTEM_PROMPT = """You are assisting an Information Security Manager who is preparing a \
cloud control monitoring report for executives.

Rules:
- Use ONLY the facts in the JSON provided. Do not invent resources, causes, dates or numbers.
- Do not decide or change any pass/fail result; they are final.
- Write plain business English for a non-technical executive. No markdown headers, no bullet symbols.
- Structure: one short paragraph on overall posture, then a paragraph starting "Top risks:" \
(highest-severity failing controls first), then a paragraph starting "Next 30 days:" \
with at most three prioritised actions.
- Mention the approved-exception position and any change since the last run when present.
- Maximum 220 words."""


# ------------------------------------------------------------------ payload ----


def build_payload(results: dict) -> dict:
    s = results["summary"]
    exceptions = results["exceptions"]
    payload = {
        "as_of": results["run"]["as_of"],
        "overall": {
            "controls_total": s["controls_total"],
            "controls_failing": s["controls"]["FAIL"],
            "controls_passing": s["controls"]["PASS"],
            "controls_passing_with_exceptions": s["controls"]["EXCEPTION"],
            "findings_total": s["findings_total"],
            "findings_failing": s["findings"]["FAIL"],
            "findings_excepted": s["findings"]["EXCEPTION"],
            "compliance_rate_strict_pct": s["compliance_rate_strict"],
            "compliance_rate_with_exceptions_pct": s["compliance_rate_adjusted"],
        },
        "controls": [
            {
                "id": c["id"],
                "title": c["title"],
                "severity": c["severity"],
                "status": c["status"],
                "pass": c["counts"]["PASS"],
                "fail": c["counts"]["FAIL"],
                "excepted": c["counts"]["EXCEPTION"],
                "issues": c["issues"],
            }
            for c in results["controls"]
        ],
        "exception_register": {
            "active": sum(e["state"] == "active" for e in exceptions),
            "expired_not_honoured": sum(e["state"] == "expired" for e in exceptions),
            "invalid_not_honoured": sum(e["state"] == "invalid" for e in exceptions),
            "expiring_within_30_days": sum(e["expiring_soon"] for e in exceptions),
            "no_longer_needed": sum(e["unused"] for e in exceptions),
        },
    }
    d = results.get("drift")
    if d:
        payload["since_last_run"] = {
            "new_failures": len(d["new_failures"]),
            "resolved": len(d["resolved"]),
            "exceptions_lapsed": len(d["exceptions_lapsed"]),
            "failures_unchanged": d["unchanged_failures"],
        }
    return payload


# ------------------------------------------------------------------ grounding ----

_NUM = re.compile(r"\d+(?:\.\d+)?")
_ALWAYS_OK = {1.0, 2.0, 3.0, 30.0}  # "three actions", "next 30 days"


def check_grounding(text: str, payload: dict) -> list[str]:
    """Return numbers in `text` that do not appear anywhere in `payload`."""
    allowed = {float(n) for n in _NUM.findall(json.dumps(payload))} | _ALWAYS_OK
    for n in list(allowed):  # allow rounded percentages, e.g. 66.7 -> 67
        allowed.add(float(round(n)))
    return sorted({n for n in _NUM.findall(text) if float(n) not in allowed})


# ------------------------------------------------------------------- template ----


def template_summary(results: dict) -> str:
    s, controls = results["summary"], results["controls"]
    failing = [c for c in controls if c["status"] == "FAIL"]
    rate = s["compliance_rate_strict"]

    posture = (
        f"{s['controls']['FAIL']} of {s['controls_total']} controls are failing. "
        f"{s['findings']['PASS']} of {s['findings_total']} checks pass"
        + (f" ({rate}% strict compliance)" if rate is not None else "")
        + (f", and {s['findings']['EXCEPTION']} more are covered by approved exceptions." if s["findings"]["EXCEPTION"] else ".")
    )
    parts = [posture]

    sev = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    top = sorted(failing, key=lambda c: sev[c["severity"]])[:3]
    if top:
        parts.append("Top risks: " + " ".join(
            f"{c['title']} ({c['severity']}): {c['counts']['FAIL']} failing." for c in top))

    exc = results["exceptions"]
    bad = [e for e in exc if e["state"] in ("expired", "invalid")]
    soon = [e for e in exc if e["expiring_soon"]]
    notes = []
    if bad:
        notes.append(f"{len(bad)} exception(s) are expired or invalid and are not being honoured")
    if soon:
        notes.append(f"{len(soon)} exception(s) expire within {results['policy']['expiring_soon_days']} days")
    if notes:
        parts.append("Exception register: " + "; ".join(notes) + ".")

    d = results.get("drift")
    if d:
        parts.append(
            f"Since the last run: {len(d['resolved'])} issue(s) resolved, "
            f"{len(d['new_failures'])} new failure(s), {len(d['exceptions_lapsed'])} lapsed exception(s)."
        )
    return "\n\n".join(parts)


# ------------------------------------------------------------------- generate ----


def generate(results: dict, mode: str = "auto", client=None, model: str | None = None) -> dict:
    """mode: 'auto' (AI if key present), 'on' (AI required), 'off' (template only)."""
    model = model or os.environ.get("CCM_MODEL", DEFAULT_MODEL)
    fallback = {"source": "template", "model": None, "text": template_summary(results), "warnings": []}

    if mode == "off":
        return fallback
    if client is None:
        if not os.environ.get("ANTHROPIC_API_KEY"):
            if mode == "on":
                raise RuntimeError("--ai on requires ANTHROPIC_API_KEY to be set")
            return fallback
        try:
            import anthropic

            client = anthropic.Anthropic()
        except ImportError:
            if mode == "on":
                raise RuntimeError("--ai on requires: pip install anthropic") from None
            return fallback

    payload = build_payload(results)
    try:
        msg = client.messages.create(
            model=model,
            max_tokens=700,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": "Control monitoring results:\n" + json.dumps(payload, indent=2)}],
        )
        text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text").strip()
        if not text:
            raise ValueError("empty response")
    except Exception as exc:  # noqa: BLE001 - never fail the report because narration failed
        if mode == "on":
            raise
        fallback["warnings"].append(f"AI summary unavailable ({type(exc).__name__}); template used instead.")
        return fallback

    ungrounded = check_grounding(text, payload)
    warnings = (
        [f"Figures not found in the source data: {', '.join(ungrounded)}. Verify before circulating."]
        if ungrounded
        else []
    )
    return {"source": "ai", "model": model, "text": text, "warnings": warnings}
