"""Read-only AWS collector.

Only Get/List/Describe calls are made. Each evidence domain (iam, cloudtrail,
s3, ebs, rds) is collected independently: if one is denied or fails, it is
recorded in ``Snapshot.errors`` and the controls that depend on it report
ERROR rather than a misleading PASS.

Scope: IAM users and the root account. Federated identities (IAM Identity
Center / SSO) and IAM roles are out of scope for this demo.
"""

from __future__ import annotations

import csv
import io
import json
import time
from datetime import datetime, timezone

from ..config import Policy
from ..models import Snapshot, StorageResource, Trail, User

_NO_VALUE = {"", "N/A", "no_information", "not_supported"}


def _ts(value: str | None) -> datetime | None:
    if value is None or value in _NO_VALUE:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _later(*values: datetime | None) -> datetime | None:
    present = [v for v in values if v]
    return max(present) if present else None


def doc_is_admin(doc: dict) -> bool:
    """True if a policy document allows Action '*' on Resource '*'."""
    stmts = doc.get("Statement", [])
    if isinstance(stmts, dict):
        stmts = [stmts]
    for s in stmts:
        if s.get("Effect") != "Allow":
            continue
        actions = s.get("Action", [])
        resources = s.get("Resource", [])
        actions = [actions] if isinstance(actions, str) else actions
        resources = [resources] if isinstance(resources, str) else resources
        if "*" in actions and "*" in resources:
            return True
    return False


def policy_enforces_tls(policy_json: str) -> bool:
    """Heuristic: a Deny statement conditioned on aws:SecureTransport = false."""
    doc = json.loads(policy_json)
    stmts = doc.get("Statement", [])
    if isinstance(stmts, dict):
        stmts = [stmts]
    for s in stmts:
        if s.get("Effect") != "Deny":
            continue
        for op, kv in (s.get("Condition") or {}).items():
            if op.lower().startswith("bool"):
                for key, val in kv.items():
                    if key.lower() == "aws:securetransport" and str(val).lower() == "false":
                        return True
    return False


class AwsCollector:
    def __init__(self, policy: Policy, profile: str | None = None, region: str | None = None, session=None):
        if session is None:
            try:
                import boto3
            except ImportError as exc:  # pragma: no cover
                raise RuntimeError("AWS source needs boto3: pip install boto3") from exc
            session = boto3.Session(profile_name=profile, region_name=region)
        self.session = session
        self.policy = policy

    # ------------------------------------------------------------------ main

    def collect(self, as_of: datetime | None = None) -> Snapshot:
        now = datetime.now(timezone.utc)
        errors: dict[str, list[str]] = {}

        def guarded(domain, fn, default):
            try:
                return fn()
            except Exception as exc:  # noqa: BLE001 - any failure means "evidence incomplete"
                errors.setdefault(domain, []).append(f"{type(exc).__name__}: {exc}")
                return default

        account_id = guarded(
            "iam", lambda: self.session.client("sts").get_caller_identity()["Account"], "unknown"
        )
        alias = guarded(
            "iam",
            lambda: next(iter(self.session.client("iam").list_account_aliases()["AccountAliases"]), ""),
            "",
        )
        regions = self._regions(errors)

        return Snapshot(
            source="aws",
            account_id=account_id,
            account_alias=alias or account_id,
            collected_at=now,
            users=guarded("iam", self._users, []),
            trails=guarded("cloudtrail", self._trails, []),
            storage=(
                guarded("s3", lambda: self._s3(errors), [])
                + guarded("ebs", lambda: self._ebs(regions, errors), [])
                + guarded("rds", lambda: self._rds(regions, errors), [])
            ),
            errors=errors,
        )

    def _regions(self, errors) -> list[str]:
        configured = list(self.policy.regions)
        if configured == ["all"]:
            try:
                resp = self.session.client("ec2").describe_regions()
                return [r["RegionName"] for r in resp["Regions"]]
            except Exception as exc:  # noqa: BLE001
                errors.setdefault("ebs", []).append(f"describe_regions: {exc}")
                return []
        return configured or [self.session.region_name or "us-east-1"]

    # ------------------------------------------------------------------- iam

    def _credential_report(self) -> list[dict]:
        iam = self.session.client("iam")
        for _ in range(20):
            if iam.generate_credential_report()["State"] == "COMPLETE":
                break
            time.sleep(1)
        content = iam.get_credential_report()["Content"].decode("utf-8")
        return list(csv.DictReader(io.StringIO(content)))

    def _is_privileged(self, iam, name: str) -> str:
        """Return a reason string if the user holds admin-level permissions, else ''."""
        pol = self.policy.privileged_policies

        for p in iam.get_paginator("list_attached_user_policies").paginate(UserName=name):
            for a in p["AttachedPolicies"]:
                if a["PolicyArn"] in pol:
                    return f"{a['PolicyName']} (attached)"
        for n in iam.list_user_policies(UserName=name)["PolicyNames"]:
            if doc_is_admin(iam.get_user_policy(UserName=name, PolicyName=n)["PolicyDocument"]):
                return f"inline policy {n} grants *:*"

        for g in iam.list_groups_for_user(UserName=name)["Groups"]:
            gname = g["GroupName"]
            for a in iam.list_attached_group_policies(GroupName=gname)["AttachedPolicies"]:
                if a["PolicyArn"] in pol:
                    return f"{a['PolicyName']} via group {gname}"
            for n in iam.list_group_policies(GroupName=gname)["PolicyNames"]:
                if doc_is_admin(iam.get_group_policy(GroupName=gname, PolicyName=n)["PolicyDocument"]):
                    return f"inline policy {n} (group {gname}) grants *:*"
        return ""

    def _users(self) -> list[User]:
        iam = self.session.client("iam")
        out = []
        for row in self._credential_report():
            is_root = row["user"] == "<root_account>"
            keys = sum(row.get(f"access_key_{i}_active") == "true" for i in (1, 2))
            last = _later(
                _ts(row.get("password_last_used")),
                _ts(row.get("access_key_1_last_used_date")),
                _ts(row.get("access_key_2_last_used_date")),
            )
            if is_root:
                privileged, why = True, "Root"
            else:
                why = self._is_privileged(iam, row["user"])
                privileged = bool(why)
            out.append(
                User(
                    name=row["user"],
                    arn=row["arn"],
                    privileged=privileged,
                    privilege_reason=why,
                    console_access=is_root or row.get("password_enabled") == "true",
                    mfa_enabled=row.get("mfa_active") == "true",
                    created=_ts(row["user_creation_time"]),
                    last_activity=last,
                    access_keys_active=keys,
                    is_root=is_root,
                )
            )
        return out

    # ------------------------------------------------------------ cloudtrail

    def _trails(self) -> list[Trail]:
        ct = self.session.client("cloudtrail")
        out = []
        for t in ct.describe_trails(includeShadowTrails=False)["trailList"]:
            home = t.get("HomeRegion") or self.session.region_name
            regional = self.session.client("cloudtrail", region_name=home)
            status = regional.get_trail_status(Name=t["TrailARN"])
            out.append(
                Trail(
                    name=t["Name"],
                    home_region=home,
                    multi_region=bool(t.get("IsMultiRegionTrail")),
                    logging=bool(status.get("IsLogging")),
                    log_file_validation=bool(t.get("LogFileValidationEnabled")),
                    kms_encrypted=bool(t.get("KmsKeyId")),
                )
            )
        return out

    # -------------------------------------------------------------------- s3

    def _s3(self, errors) -> list[StorageResource]:
        from botocore.exceptions import ClientError

        s3 = self.session.client("s3")
        out = []
        for b in s3.list_buckets()["Buckets"]:
            name = b["Name"]
            encrypted, algo, tls = False, "", False
            try:
                rules = s3.get_bucket_encryption(Bucket=name)["ServerSideEncryptionConfiguration"]["Rules"]
                algo = rules[0]["ApplyServerSideEncryptionByDefault"]["SSEAlgorithm"]
                encrypted = True
            except ClientError as exc:
                if exc.response["Error"]["Code"] != "ServerSideEncryptionConfigurationNotFoundError":
                    errors.setdefault("s3", []).append(f"{name}: {exc.response['Error']['Code']}")
                    continue
            try:
                tls = policy_enforces_tls(s3.get_bucket_policy(Bucket=name)["Policy"])
            except ClientError as exc:
                if exc.response["Error"]["Code"] != "NoSuchBucketPolicy":
                    errors.setdefault("s3", []).append(f"{name}: {exc.response['Error']['Code']}")
                    continue
            out.append(StorageResource("s3", name, "global", encrypted, algo, tls))
        return out

    # ------------------------------------------------------------- ebs / rds

    def _ebs(self, regions, errors) -> list[StorageResource]:
        out = []
        for region in regions:
            try:
                ec2 = self.session.client("ec2", region_name=region)
                for page in ec2.get_paginator("describe_volumes").paginate():
                    out += [
                        StorageResource("ebs", v["VolumeId"], region, bool(v["Encrypted"]))
                        for v in page["Volumes"]
                    ]
            except Exception as exc:  # noqa: BLE001
                errors.setdefault("ebs", []).append(f"{region}: {type(exc).__name__}")
        return out

    def _rds(self, regions, errors) -> list[StorageResource]:
        out = []
        for region in regions:
            try:
                rds = self.session.client("rds", region_name=region)
                for page in rds.get_paginator("describe_db_instances").paginate():
                    out += [
                        StorageResource("rds", d["DBInstanceIdentifier"], region, bool(d["StorageEncrypted"]))
                        for d in page["DBInstances"]
                    ]
            except Exception as exc:  # noqa: BLE001
                errors.setdefault("rds", []).append(f"{region}: {type(exc).__name__}")
        return out
