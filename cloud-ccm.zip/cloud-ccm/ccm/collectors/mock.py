"""Mock collector: replays a fictional environment from a JSON scenario.

Times are stored as "days ago" so the scenario stays realistic whatever the
as-of date is. This lets the whole project run with no cloud account.
"""

from __future__ import annotations

import json
from datetime import datetime, time, timedelta, timezone
from pathlib import Path

from ..models import Snapshot, StorageResource, Trail, User

SCENARIO_DIR = Path(__file__).parent / "scenarios"


def available_scenarios() -> list[str]:
    return sorted(p.stem for p in SCENARIO_DIR.glob("*.json"))


class MockCollector:
    def __init__(self, scenario: str = "baseline"):
        path = SCENARIO_DIR / f"{scenario}.json"
        if not path.exists():
            raise FileNotFoundError(
                f"Unknown scenario '{scenario}'. Available: {', '.join(available_scenarios())}"
            )
        self.scenario = scenario
        self.data = json.loads(path.read_text(encoding="utf-8"))

    def collect(self, as_of: datetime) -> Snapshot:
        d, acct = self.data, self.data["account_id"]

        def ago(days):
            return None if days is None else as_of - timedelta(days=days)

        users = []
        for u in d["users"]:
            root = u.get("is_root", False)
            users.append(
                User(
                    name=u["name"],
                    arn=f"arn:aws:iam::{acct}:root" if root else f"arn:aws:iam::{acct}:user/{u['name']}",
                    privileged=u["privileged"],
                    privilege_reason=u.get("privilege_reason", ""),
                    console_access=u["console_access"],
                    mfa_enabled=u["mfa_enabled"],
                    created=ago(u["created_days_ago"]),
                    last_activity=ago(u.get("last_activity_days_ago")),
                    access_keys_active=u.get("access_keys_active", 0),
                    is_root=root,
                )
            )
        return Snapshot(
            source=f"mock:{self.scenario}",
            account_id=acct,
            account_alias=d["account_alias"],
            collected_at=as_of,
            users=users,
            trails=[Trail(**t) for t in d["trails"]],
            storage=[StorageResource(**s) for s in d["storage"]],
            errors=d.get("errors", {}),
        )


def as_of_datetime(day) -> datetime:
    """Noon UTC on the given date, so 'days ago' arithmetic is stable."""
    return datetime.combine(day, time(12, 0), tzinfo=timezone.utc)
