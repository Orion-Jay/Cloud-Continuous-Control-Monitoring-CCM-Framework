"""Evaluation engine: snapshot + policy + exception register -> results dict.

The results dict is the single source of truth. The JSON file, Markdown and
HTML reports, drift detection and the AI summary are all views of it.
"""

from __future__ import annotations

from collections import Counter
from datetime import date, datetime, timezone

from . import __version__
from .config import Policy
from .controls import CONTROLS, REASONS
from .exceptions import ExceptionRecord, apply_exceptions
from .models import Finding, Snapshot, Status

_ORDER = {Status.FAIL: 0, Status.ERROR: 1, Status.EXCEPTION: 2, Status.PASS: 3, Status.NA: 4}


def _control_status(findings: list[Finding], errors: dict[str, list[str]]) -> Status:
    statuses = {f.status for f in findings}
    if Status.FAIL in statuses:
        return Status.FAIL
    if errors:
        return Status.ERROR  # incomplete evidence can never be reported as PASS
    if Status.EXCEPTION in statuses:
        return Status.EXCEPTION
    return Status.PASS if findings else Status.NA


def _rate(numerator: int, denominator: int) -> float | None:
    return round(100 * numerator / denominator, 1) if denominator else None


def evaluate(
    snapshot: Snapshot,
    policy: Policy,
    exception_records: list[ExceptionRecord],
    as_of: date,
) -> dict:
    # 1. run every check
    findings_by_control: dict[str, list[Finding]] = {}
    for control in CONTROLS:
        findings_by_control[control.id] = control.check(snapshot, policy)

    # 2. apply the exception register across all findings at once
    all_findings = [f for fs in findings_by_control.values() for f in fs]
    exception_rows = apply_exceptions(all_findings, exception_records, as_of, policy)

    # 3. aggregate per control
    controls_out = []
    for control in CONTROLS:
        findings = sorted(findings_by_control[control.id], key=lambda f: (_ORDER[f.status], f.resource))
        errors = {d: snapshot.errors[d] for d in control.requires if d in snapshot.errors}
        status = _control_status(findings, errors)
        counts = Counter(f.status.value for f in findings)
        issues = Counter(
            REASONS[r] for f in findings if f.status in (Status.FAIL, Status.EXCEPTION) for r in f.reasons
        )
        controls_out.append(
            {
                "id": control.id,
                "title": control.title,
                "description": control.description,
                "severity": control.severity.value,
                "status": status.value,
                "counts": {s.value: counts.get(s.value, 0) for s in (Status.PASS, Status.FAIL, Status.EXCEPTION)},
                "mappings": control.mappings,
                "remediation": control.remediation,
                "collection_errors": errors,
                "issues": [{"issue": k, "count": v} for k, v in issues.most_common()],
                "findings": [f.to_dict() for f in findings],
            }
        )

    # 4. headline numbers
    f_counts = Counter(f.status.value for f in all_findings)
    p, fl, ex = f_counts.get("PASS", 0), f_counts.get("FAIL", 0), f_counts.get("EXCEPTION", 0)
    total = p + fl + ex
    c_counts = Counter(c["status"] for c in controls_out)

    now = datetime.now(timezone.utc)
    return {
        "schema_version": "1.0",
        "tool": {"name": "cloud-ccm", "version": __version__},
        "run": {
            "id": now.strftime("%Y%m%dT%H%M%S%fZ"),
            "generated_at": now.isoformat(timespec="seconds"),
            "as_of": as_of.isoformat(),
            "source": snapshot.source,
            "account_id": snapshot.account_id,
            "account_alias": snapshot.account_alias,
        },
        "policy": policy.to_dict(),
        "summary": {
            "controls_total": len(controls_out),
            "controls": {s.value: c_counts.get(s.value, 0) for s in Status},
            "findings_total": total,
            "findings": {"PASS": p, "FAIL": fl, "EXCEPTION": ex},
            # strict: exceptions count against you. adjusted: approved exceptions don't.
            "compliance_rate_strict": _rate(p, total),
            "compliance_rate_adjusted": _rate(p + ex, total),
        },
        "controls": controls_out,
        "exceptions": exception_rows,
        "collection_errors": snapshot.errors,
        "drift": None,
        "executive_summary": None,
    }


def worst_failing_severity(results: dict) -> int:
    """Highest severity rank among failing controls (-1 if none fail)."""
    order = ["low", "medium", "high", "critical"]
    ranks = [order.index(c["severity"]) for c in results["controls"] if c["status"] == "FAIL"]
    return max(ranks, default=-1)
