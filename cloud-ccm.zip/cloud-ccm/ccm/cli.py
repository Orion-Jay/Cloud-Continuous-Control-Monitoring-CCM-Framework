"""Command line interface.

    python -m ccm run --source mock --scenario baseline
    python -m ccm run --source aws --profile audit-readonly
    python -m ccm demo
"""

from __future__ import annotations

import argparse
import shutil
import sys
from datetime import date, datetime, timezone
from pathlib import Path

from . import ai_summary, history
from .collectors import AwsCollector, MockCollector
from .collectors.mock import as_of_datetime, available_scenarios
from .config import ConfigError, load_policy
from .engine import evaluate, worst_failing_severity
from .exceptions import load_exceptions
from .report import write_reports

_SEV_RANK = {"any": 0, "high": 2, "none": 99}  # rank of the lowest failing severity that breaks the build


def _parse_args(argv):
    p = argparse.ArgumentParser(prog="ccm", description="Continuous control monitoring for cloud accounts.")
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp):
        sp.add_argument("--config", type=Path, default=Path("config"), help="folder with settings.toml and exceptions.toml")
        sp.add_argument("--out", type=Path, default=Path("output"), help="where reports and run history are written")
        sp.add_argument("--ai", choices=["auto", "on", "off"], default="auto",
                        help="executive summary: auto = Claude if ANTHROPIC_API_KEY is set, else template")
        sp.add_argument("--no-history", action="store_true", help="do not read or write run history")

    run = sub.add_parser("run", help="collect evidence, evaluate controls, write reports")
    common(run)
    run.add_argument("--source", choices=["mock", "aws"], default="mock")
    run.add_argument("--scenario", default="baseline", help=f"mock only. one of: {', '.join(available_scenarios())}")
    run.add_argument("--as-of", type=date.fromisoformat, help="mock only. pin the evaluation date (YYYY-MM-DD)")
    run.add_argument("--profile", help="aws only. named credentials profile")
    run.add_argument("--region", help="aws only. default region for the session")
    run.add_argument("--fail-on", choices=list(_SEV_RANK), default="any",
                     help="exit 1 if a control fails at/above this level: any | high (high+critical) | none")

    demo = sub.add_parser("demo", help="run the baseline then the remediated scenario to show drift")
    common(demo)
    demo.add_argument("--as-of", type=date.fromisoformat, default=date(2026, 11, 17))
    return p.parse_args(argv)


def _run_once(args, scenario: str | None = None, as_of: date | None = None) -> tuple[dict, dict]:
    policy = load_policy(args.config / "settings.toml")
    records = load_exceptions(args.config / "exceptions.toml")
    history_dir = args.out / "history"

    if getattr(args, "source", "mock") == "aws":
        snapshot = AwsCollector(policy, profile=args.profile, region=args.region).collect()
        eval_date = snapshot.collected_at.date()
    else:
        eval_date = as_of or args.as_of or datetime.now(timezone.utc).date()
        snapshot = MockCollector(scenario or args.scenario).collect(as_of_datetime(eval_date))

    results = evaluate(snapshot, policy, records, eval_date)

    if not args.no_history:
        prev = history.latest(history_dir)
        results["drift"] = history.compute_drift(prev, results) if prev else None

    results["executive_summary"] = ai_summary.generate(results, mode=args.ai)
    paths = write_reports(results, args.out)
    if not args.no_history:
        history.save(history_dir, results)
    return results, paths


def _print_summary(results: dict, paths: dict) -> None:
    s = results["summary"]
    print(f"\n{results['run']['source']} · as of {results['run']['as_of']}")
    for c in results["controls"]:
        n = c["counts"]
        print(f"  {c['status']:<9} {c['id']}  {c['title']}  (P{n['PASS']} F{n['FAIL']} E{n['EXCEPTION']})")
    print(f"  → {s['findings']['PASS']} pass, {s['findings']['FAIL']} fail, {s['findings']['EXCEPTION']} exception "
          f"· strict compliance {s['compliance_rate_strict']}%")
    d = results.get("drift")
    if d:
        print(f"  → since last run: {len(d['resolved'])} resolved, {len(d['new_failures'])} new, "
              f"{len(d['exceptions_lapsed'])} lapsed exceptions")
    ex = results["executive_summary"]
    print(f"  → executive summary: {ex['source']}" + (f" ({ex['model']})" if ex["model"] else ""))
    for w in ex["warnings"]:
        print(f"    ! {w}")
    print(f"  → report: {paths['html']}")


def main(argv=None) -> int:
    args = _parse_args(argv)
    try:
        if args.cmd == "demo":
            if not args.no_history:
                shutil.rmtree(args.out / "history", ignore_errors=True)  # start the demo from a clean baseline
            for scenario in ("baseline", "remediated"):
                results, paths = _run_once(args, scenario=scenario, as_of=args.as_of)
                _print_summary(results, paths)
            return 0

        if args.source == "aws" and args.as_of:
            print("error: --as-of only applies to --source mock", file=sys.stderr)
            return 2
        results, paths = _run_once(args)
        _print_summary(results, paths)
        threshold = _SEV_RANK[args.fail_on]
        return 1 if worst_failing_severity(results) >= threshold and args.fail_on != "none" else 0
    except (ConfigError, FileNotFoundError, RuntimeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
