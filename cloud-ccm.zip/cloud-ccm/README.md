# cloud-ccm: Continuous Control Monitoring for cloud accounts

A small, working demonstration of **continuous control monitoring (CCM)**: automated, repeatable checks that
test cloud security controls against live configuration, map results to ISO 27001, PCI DSS, NIST CSF and SOC 2,
manage approved exceptions, track drift between runs, and produce an audit-ready report.

It runs with **zero setup** on a fictional environment, and against a real AWS account with a read-only role.

> **Sample output:** open [`examples/report.html`](examples/report.html) (or [`report.md`](examples/report.md)) to see a finished report.

## Quick start

```bash
python -m ccm demo                       # baseline run, then a remediated run, showing drift. Needs Python 3.11+, no installs
open output/report.html                 # latest report

python -m ccm run --scenario baseline --as-of 2026-11-17      # single run
python -m ccm run --source aws --profile audit-readonly       # real account (pip install boto3)
ANTHROPIC_API_KEY=... python -m ccm run --ai on               # Claude-written executive summary (pip install anthropic)
python -m pytest                                              # 44 tests (pip install -r requirements-dev.txt)
```

Exit code is `1` when a control fails (`--fail-on any`, default), so it can gate a pipeline. Use `--fail-on high` or `none` to tune.

## What it checks

| ID | Control | Severity | ISO 27001:2022 | PCI DSS v4.0.1 | NIST CSF 2.0 | SOC 2 |
|---|---|---|---|---|---|---|
| CCM-01 | MFA enforced for privileged accounts (root must also have no access keys) | Critical | A.8.5 | 8.4.1 | PR.AA-03 | CC6.1 |
| CCM-02 | Inactive accounts disabled or removed (default 90 days; never-used counts) | High | A.5.18 | 8.2.6 | PR.AA-05 | CC6.2 |
| CCM-03 | Audit logging enabled and protected (multi-region trail, integrity validation, KMS) | Critical | A.8.15 | 10.2.1, 10.3.4 | DE.CM-03 | CC7.2 |
| CCM-04 | Encryption at rest (S3 with KMS, EBS, RDS) | High | A.8.24 | 3.5.1 | PR.DS-01 | CC6.1 |
| CCM-05 | Encryption in transit enforced on S3 (TLS-only bucket policy) | Medium | A.8.24 | 4.2.1 | PR.DS-02 | CC6.7 |

Framework references are indicative mappings for orientation, not an assurance opinion. Verify against your own scope and framework version.

## How it works

```mermaid
flowchart LR
    A[Collector<br/>mock or AWS read-only] --> B[Snapshot<br/>normalised evidence]
    B --> C[Deterministic checks<br/>pure functions]
    D[Policy<br/>settings.toml] --> C
    C --> E[Exception register<br/>exceptions.toml]
    E --> F[Results<br/>single source of truth]
    G[Previous run] --> H[Drift detection]
    F --> H
    F --> I[AI summary<br/>aggregates only]
    F --> J[HTML / Markdown / JSON]
    H --> J
    I --> J
```

Each result is **PASS**, **FAIL**, **EXCEPTION** (failed but covered by an approved exception), **ERROR** (evidence couldn't be
collected) or **N/A** (no in-scope resources).

### Design decisions

**Code decides, Claude narrates.** Every pass/fail is computed by a deterministic function, so results are reproducible and
defensible to an auditor. Claude is used only to write the executive summary, and three guardrails apply
(`ccm/ai_summary.py`):

1. *Data minimisation.* The prompt contains counts and issue categories only. No usernames, bucket names, volume IDs, ARNs or account IDs are sent (tested).
2. *Grounding check.* Every number in the narrative must exist in the data that was sent. Anything else is flagged in the report.
3. *Graceful degradation.* No API key or an API error falls back to a template summary, and the report labels which one you're reading.

**Exceptions are governed, not just tolerated.** An exception only downgrades a failure if it is approved, in date, and within the
policy's maximum duration (default 180 days). Expired or over-long exceptions are *not honoured* and say why. The register also flags
exceptions expiring soon and exceptions that no longer match anything, so it doesn't rot.

**Incomplete evidence never becomes a pass.** If a collector call is denied, the controls that depend on it report `ERROR`, not `PASS`.
A `FAIL` still outranks `ERROR`, because a failure is real regardless of what else couldn't be read.

**Strict config.** Unknown keys in `settings.toml` are rejected, so a typo can't silently weaken a threshold.

**Strict and adjusted compliance rates.** Strict counts exceptions against you; adjusted doesn't. Showing both keeps the exception
count visible instead of flattering the headline.

## Project layout

```
ccm/
  controls.py        control catalogue + checks (pure functions)
  engine.py          run checks, apply exceptions, aggregate
  exceptions.py      exception register logic
  history.py         run history + drift detection
  ai_summary.py      Claude summary with guardrails + template fallback
  report.py          HTML / Markdown / JSON
  collectors/        mock.py (+ scenarios/), aws.py (read-only)
config/              settings.toml, exceptions.toml
docs/                aws-readonly-policy.json
tests/               44 tests, incl. AWS collector against moto
```

### Adding a control

1. Write `check_x(snapshot, policy) -> list[Finding]` in `controls.py` and add reason codes to `REASONS`.
2. Add a `Control(...)` entry to `CONTROLS` with its mappings, remediation and the evidence domains it `requires`.
3. If it needs new evidence, add a field to `Snapshot` and collect it in `collectors/aws.py` and the mock scenarios.

## Running against AWS

Create a read-only role with [`docs/aws-readonly-policy.json`](docs/aws-readonly-policy.json) (or the managed `SecurityAudit` policy)
and run `python -m ccm run --source aws --profile <profile>`. Only `Get`, `List` and `Describe` calls are made. For CI, use GitHub
OIDC to assume that role (see `.github/workflows/ccm.yml`) rather than storing keys.

## Limitations (deliberate, for a demo)

- **Scope:** IAM users and root only. Federated identities (IAM Identity Center / SSO) and IAM roles are not assessed.
- **Privilege detection:** admin = attached `AdministratorAccess`/`IAMFullAccess` (configurable), or inline policies allowing `*:*`, directly or via group. Permission boundaries and SCPs are not evaluated.
- **TLS check** is a heuristic: a Deny statement conditioned on `aws:SecureTransport = false`.
- **Programmatic-only privileged identities** pass CCM-01 (no console MFA to enforce) with a note; long-lived key hygiene is a natural next control.
- **Single account, AWS only.** The `Snapshot` model is provider-neutral, so adding Azure or GCP means writing one collector.
- The AWS collector is tested against `moto`, not a live account. The Claude path is tested with a stub client, not live API calls.
- Mock data is entirely fictional (account `111122223333` is AWS's documentation example).

## Ideas for next steps

Key-age and unused-access-key checks · S3 public-access-block · security-group exposure · Azure/GCP collectors · push results to a
GRC tool or ticketing system · trend charts across run history · SARIF output for code-scanning dashboards.
